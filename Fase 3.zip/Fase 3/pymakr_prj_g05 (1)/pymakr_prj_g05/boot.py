# boot.py -- run on boot-up
import machine


machine.main("send.py")
